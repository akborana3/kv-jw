"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, Heart, ShoppingCart, Eye } from "lucide-react"
import { useCart } from "@/components/cart-provider"

interface Product {
  id: string
  name: string
  price: number
  originalPrice?: number
  image: string
  rating: number
  reviews: number
  category: string
  isNew?: boolean
  description: string
}

const allProducts: Product[] = [
  {
    id: "1",
    name: "Golden Elegance Necklace",
    price: 2999,
    originalPrice: 3999,
    image: "/placeholder.svg?height=300&width=300",
    rating: 4.8,
    reviews: 124,
    category: "Necklaces",
    isNew: true,
    description: "Exquisite gold-plated necklace with intricate design",
  },
  {
    id: "2",
    name: "Royal Diamond Ring",
    price: 1899,
    image: "/placeholder.svg?height=300&width=300",
    rating: 4.9,
    reviews: 89,
    category: "Rings",
    description: "Stunning diamond-studded ring for special occasions",
  },
  {
    id: "3",
    name: "Vintage Pearl Earrings",
    price: 1299,
    originalPrice: 1599,
    image: "/placeholder.svg?height=300&width=300",
    rating: 4.7,
    reviews: 156,
    category: "Earrings",
    description: "Classic pearl earrings with vintage charm",
  },
  {
    id: "4",
    name: "Classic Gold Bracelet",
    price: 2199,
    image: "/placeholder.svg?height=300&width=300",
    rating: 4.6,
    reviews: 78,
    category: "Bracelets",
    isNew: true,
    description: "Elegant gold bracelet for everyday wear",
  },
  {
    id: "5",
    name: "Luxury Chain Set",
    price: 3499,
    originalPrice: 4299,
    image: "/placeholder.svg?height=300&width=300",
    rating: 4.9,
    reviews: 203,
    category: "Sets",
    description: "Complete jewelry set with matching pieces",
  },
  {
    id: "6",
    name: "Designer Pendant",
    price: 1699,
    image: "/placeholder.svg?height=300&width=300",
    rating: 4.5,
    reviews: 92,
    category: "Pendants",
    description: "Unique designer pendant with modern appeal",
  },
  {
    id: "7",
    name: "Emerald Statement Ring",
    price: 2799,
    image: "/placeholder.svg?height=300&width=300",
    rating: 4.8,
    reviews: 67,
    category: "Rings",
    description: "Bold emerald ring that makes a statement",
  },
  {
    id: "8",
    name: "Pearl Drop Earrings",
    price: 1599,
    originalPrice: 1999,
    image: "/placeholder.svg?height=300&width=300",
    rating: 4.6,
    reviews: 134,
    category: "Earrings",
    description: "Elegant pearl drop earrings for formal occasions",
  },
]

interface ProductGridProps {
  viewMode: "grid" | "list"
  filters: {
    category: string
    priceRange: number[]
    sortBy: string
  }
}

export default function ProductGrid({ viewMode, filters }: ProductGridProps) {
  const [filteredProducts, setFilteredProducts] = useState<Product[]>(allProducts)
  const { addToCart } = useCart()

  useEffect(() => {
    let filtered = [...allProducts]

    // Filter by category
    if (filters.category && filters.category !== "All") {
      filtered = filtered.filter((product) => product.category === filters.category)
    }

    // Filter by price range
    filtered = filtered.filter(
      (product) => product.price >= filters.priceRange[0] && product.price <= filters.priceRange[1],
    )

    // Sort products
    switch (filters.sortBy) {
      case "price-low":
        filtered.sort((a, b) => a.price - b.price)
        break
      case "price-high":
        filtered.sort((a, b) => b.price - a.price)
        break
      case "rating":
        filtered.sort((a, b) => b.rating - a.rating)
        break
      case "newest":
        filtered.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0))
        break
      default:
        // popularity - keep original order
        break
    }

    setFilteredProducts(filtered)
  }, [filters])

  const handleAddToCart = (product: Product) => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
    })
  }

  if (viewMode === "list") {
    return (
      <div className="space-y-6">
        {filteredProducts.map((product) => (
          <Card key={product.id} className="glass-effect border-0 hover:shadow-lg transition-all duration-300">
            <CardContent className="p-0">
              <div className="flex flex-col sm:flex-row">
                <div className="relative w-full sm:w-48 h-48 flex-shrink-0">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    fill
                    className="object-cover rounded-l-lg"
                  />
                  {product.isNew && <Badge className="absolute top-2 left-2 bg-yellow-400 text-black">NEW</Badge>}
                </div>

                <div className="flex-1 p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <span className="text-sm text-yellow-400 font-medium">{product.category}</span>
                      <h3 className="text-xl font-semibold mb-2">
                        <Link href={`/product/${product.id}`} className="hover:text-yellow-400 transition-colors">
                          {product.name}
                        </Link>
                      </h3>
                      <p className="text-muted-foreground mb-3">{product.description}</p>

                      <div className="flex items-center gap-2 mb-3">
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-sm text-muted-foreground">
                          {product.rating} ({product.reviews})
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-2xl font-bold text-yellow-400">₹{product.price.toLocaleString()}</span>
                        {product.originalPrice && (
                          <span className="text-lg text-muted-foreground line-through">
                            ₹{product.originalPrice.toLocaleString()}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-col gap-2">
                      <Button size="icon" variant="outline">
                        <Heart className="w-4 h-4" />
                      </Button>
                      <Link href={`/product/${product.id}`}>
                        <Button size="icon" variant="outline">
                          <Eye className="w-4 h-4" />
                        </Button>
                      </Link>
                      <Button
                        size="icon"
                        onClick={() => handleAddToCart(product)}
                        className="bg-yellow-400 hover:bg-yellow-500 text-black"
                      >
                        <ShoppingCart className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {filteredProducts.map((product) => (
        <Card
          key={product.id}
          className="group glass-effect border-0 hover:shadow-2xl hover:shadow-yellow-400/10 transition-all duration-500 hover:scale-105"
        >
          <CardContent className="p-0">
            <div className="relative overflow-hidden rounded-t-lg">
              <div className="relative aspect-square">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />

                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />

                <div className="absolute top-4 left-4 flex flex-col gap-2">
                  {product.isNew && <Badge className="bg-yellow-400 text-black font-semibold">NEW</Badge>}
                  {product.originalPrice && (
                    <Badge variant="destructive" className="bg-red-500">
                      SALE
                    </Badge>
                  )}
                </div>

                <div className="absolute top-4 right-4 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Button size="icon" variant="secondary" className="rounded-full bg-white/90 hover:bg-white">
                    <Heart className="w-4 h-4" />
                  </Button>
                  <Link href={`/product/${product.id}`}>
                    <Button size="icon" variant="secondary" className="rounded-full bg-white/90 hover:bg-white">
                      <Eye className="w-4 h-4" />
                    </Button>
                  </Link>
                </div>

                <div className="absolute bottom-4 left-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Button
                    onClick={() => handleAddToCart(product)}
                    className="w-full bg-yellow-400 hover:bg-yellow-500 text-black font-semibold"
                  >
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    Add to Cart
                  </Button>
                </div>
              </div>
            </div>

            <div className="p-4">
              <div className="mb-2">
                <span className="text-sm text-yellow-400 font-medium">{product.category}</span>
              </div>

              <h3 className="font-semibold text-lg mb-2 group-hover:text-yellow-400 transition-colors">
                <Link href={`/product/${product.id}`}>{product.name}</Link>
              </h3>

              <div className="flex items-center gap-2 mb-3">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground">({product.reviews})</span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xl font-bold text-yellow-400">₹{product.price.toLocaleString()}</span>
                {product.originalPrice && (
                  <span className="text-sm text-muted-foreground line-through">
                    ₹{product.originalPrice.toLocaleString()}
                  </span>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
