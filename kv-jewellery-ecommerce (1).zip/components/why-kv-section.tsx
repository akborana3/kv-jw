"use client"

import { Truck, Shield, RotateCcw, Award } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const features = [
  {
    icon: Truck,
    title: "24/7 Delivery",
    description: "Fast and reliable delivery service available round the clock",
  },
  {
    icon: Shield,
    title: "Razorpay Secure",
    description: "Your payments are protected with bank-level security",
  },
  {
    icon: RotateCcw,
    title: "Easy Returns",
    description: "Hassle-free returns within 30 days of purchase",
  },
  {
    icon: Award,
    title: "Handpicked Quality",
    description: "Every piece is carefully selected for premium quality",
  },
]

export default function WhyKVSection() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-background to-yellow-400/5">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-playfair font-bold mb-4">
            Why Choose{" "}
            <span className="bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
              KV Jewellery
            </span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Experience luxury shopping with unmatched service and quality
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Card
              key={feature.title}
              className="group glass-effect border-0 hover:shadow-2xl hover:shadow-yellow-400/10 transition-all duration-500 hover:scale-105 text-center"
            >
              <CardContent className="p-8">
                <div className="mb-6">
                  <div className="w-16 h-16 mx-auto bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <feature.icon className="w-8 h-8 text-black" />
                  </div>
                </div>

                <h3 className="text-xl font-semibold mb-3 group-hover:text-yellow-400 transition-colors">
                  {feature.title}
                </h3>

                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
