// Run this script to create an admin user in MongoDB
// Usage: node scripts/seed-admin.js

const { MongoClient } = require("mongodb")
const bcrypt = require("bcryptjs")

const MONGODB_URI =
  "mongodb+srv://akay2004:Shivam8083@cluster0.o2lne.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

async function seedAdmin() {
  const client = new MongoClient(MONGODB_URI)

  try {
    await client.connect()
    console.log("Connected to MongoDB")

    const db = client.db("kv-jewellery")

    // Check if admin already exists
    const existingAdmin = await db.collection("users").findOne({
      email: "admin@kvjewellery.com",
    })

    if (existingAdmin) {
      console.log("Admin user already exists")
      return
    }

    // Create admin user
    const hashedPassword = await bcrypt.hash("admin123", 12)

    const adminUser = {
      name: "KV Jewellery Admin",
      email: "admin@kvjewellery.com",
      password: hashedPassword,
      isAdmin: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    await db.collection("users").insertOne(adminUser)
    console.log("✅ Admin user created successfully!")
    console.log("📧 Email: admin@kvjewellery.com")
    console.log("🔑 Password: admin123")
    console.log("🌐 Access: /admin/login")
  } catch (error) {
    console.error("❌ Error seeding admin:", error)
  } finally {
    await client.close()
  }
}

seedAdmin()
