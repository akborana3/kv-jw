// Run this script to seed sample products in MongoDB
// Usage: node scripts/seed-products.js

const { MongoClient } = require("mongodb")

const MONGODB_URI =
  "mongodb+srv://akay2004:Shivam8083@cluster0.o2lne.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

const sampleProducts = [
  {
    name: "Golden Elegance Necklace",
    slug: "golden-elegance-necklace",
    description:
      "Exquisite gold-plated necklace with intricate design that embodies luxury and elegance. Crafted with precision and attention to detail, this piece is perfect for special occasions and everyday glamour.",
    price: 2999,
    originalPrice: 3999,
    category: "Necklaces",
    images: ["/placeholder.svg?height=600&width=600"],
    inStock: true,
    featured: true,
    specifications: {
      Material: "Gold-plated Silver",
      Length: "18 inches",
      Weight: "25 grams",
      "Clasp Type": "Lobster Clasp",
      Care: "Avoid water and chemicals",
    },
    features: [
      "Premium gold-plated silver base",
      "Hypoallergenic and skin-friendly",
      "Tarnish-resistant coating",
      "Handcrafted with precision",
      "Comes with luxury gift box",
    ],
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    name: "Royal Diamond Ring",
    slug: "royal-diamond-ring",
    description:
      "Stunning diamond-studded ring that captures light beautifully. Perfect for engagements, anniversaries, or as a statement piece.",
    price: 1899,
    category: "Rings",
    images: ["/placeholder.svg?height=600&width=600"],
    inStock: true,
    featured: false,
    specifications: {
      Material: "Gold-plated Silver with CZ",
      Size: "Adjustable (6-8)",
      "Stone Count": "7 pieces",
      Weight: "8 grams",
      Setting: "Prong Setting",
    },
    features: [
      "Cubic zirconia stones",
      "Adjustable size",
      "Premium gold plating",
      "Scratch-resistant surface",
      "Lifetime warranty",
    ],
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    name: "Vintage Pearl Earrings",
    slug: "vintage-pearl-earrings",
    description:
      "Classic pearl earrings with vintage charm that complement any outfit. These timeless pieces add elegance to both casual and formal looks.",
    price: 1299,
    originalPrice: 1599,
    category: "Earrings",
    images: ["/placeholder.svg?height=600&width=600"],
    inStock: true,
    featured: true,
    specifications: {
      Material: "Gold-plated Silver with Pearls",
      "Pearl Size": "8mm",
      Weight: "6 grams",
      "Back Type": "Push Back",
      Care: "Store in soft cloth",
    },
    features: [
      "Natural freshwater pearls",
      "Secure push-back closure",
      "Hypoallergenic materials",
      "Classic vintage design",
      "Perfect for daily wear",
    ],
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    name: "Classic Gold Bracelet",
    slug: "classic-gold-bracelet",
    description:
      "Elegant gold bracelet for everyday wear. This versatile piece can be worn alone or stacked with other bracelets for a trendy look.",
    price: 2199,
    category: "Bracelets",
    images: ["/placeholder.svg?height=600&width=600"],
    inStock: true,
    featured: false,
    specifications: {
      Material: "Gold-plated Silver",
      Length: "7.5 inches",
      Width: "8mm",
      Weight: "15 grams",
      Clasp: "Magnetic Clasp",
    },
    features: [
      "Comfortable magnetic clasp",
      "Adjustable length",
      "Durable construction",
      "Stackable design",
      "Everyday elegance",
    ],
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    name: "Luxury Chain Set",
    slug: "luxury-chain-set",
    description:
      "Complete jewelry set with matching pieces including necklace, earrings, and bracelet. Perfect for special occasions and gifting.",
    price: 3499,
    originalPrice: 4299,
    category: "Sets",
    images: ["/placeholder.svg?height=600&width=600"],
    inStock: true,
    featured: true,
    specifications: {
      Material: "Gold-plated Silver",
      "Set Includes": "Necklace, Earrings, Bracelet",
      "Necklace Length": "20 inches",
      Weight: "45 grams",
      "Gift Box": "Included",
    },
    features: [
      "Complete matching set",
      "Premium gift packaging",
      "Coordinated design",
      "Special occasion ready",
      "Excellent value",
    ],
    createdAt: new Date(),
    updatedAt: new Date(),
  },
]

async function seedProducts() {
  const client = new MongoClient(MONGODB_URI)

  try {
    await client.connect()
    console.log("Connected to MongoDB")

    const db = client.db("kv-jewellery")

    // Clear existing products
    await db.collection("products").deleteMany({})
    console.log("Cleared existing products")

    // Insert sample products
    const result = await db.collection("products").insertMany(sampleProducts)
    console.log(`✅ Inserted ${result.insertedCount} sample products`)

    // List inserted products
    sampleProducts.forEach((product, index) => {
      console.log(`${index + 1}. ${product.name} - ₹${product.price}`)
    })
  } catch (error) {
    console.error("❌ Error seeding products:", error)
  } finally {
    await client.close()
  }
}

seedProducts()
