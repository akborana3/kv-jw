export interface User {
  _id?: string
  name: string
  email: string
  password: string
  isAdmin: boolean
  createdAt: Date
  updatedAt: Date
}

export interface Product {
  _id?: string
  name: string
  slug: string
  description: string
  price: number
  originalPrice?: number
  category: string
  images: string[]
  inStock: boolean
  featured: boolean
  specifications: { [key: string]: string }
  features: string[]
  createdAt: Date
  updatedAt: Date
}

export interface Order {
  _id?: string
  userId: string
  items: {
    productId: string
    name: string
    price: number
    quantity: number
    image: string
  }[]
  total: number
  status: "pending" | "processing" | "shipped" | "delivered" | "cancelled"
  shippingInfo: {
    firstName: string
    lastName: string
    email: string
    phone: string
    address: string
    city: string
    state: string
    pincode: string
    country: string
  }
  paymentMethod: string
  paymentStatus: "pending" | "paid" | "failed"
  createdAt: Date
  updatedAt: Date
}

export interface Review {
  _id?: string
  productId: string
  userId: string
  userName: string
  rating: number
  comment: string
  approved: boolean
  createdAt: Date
  updatedAt: Date
}
