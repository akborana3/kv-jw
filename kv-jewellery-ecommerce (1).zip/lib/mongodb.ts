import { MongoClient, type Db } from "mongodb"

const uri = "mongodb+srv://akay2004:Shivam8083@cluster0.o2lne.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
const options = {}

let client: MongoClient
let db: Db

export async function connectToDatabase() {
  if (!client) {
    client = new MongoClient(uri, options)
    await client.connect()
    db = client.db("kv-jewellery")
  }
  return { client, db }
}

export async function getDatabase(): Promise<Db> {
  if (!db) {
    await connectToDatabase()
  }
  return db
}

// Initialize database collections and indexes
export async function initializeDatabase() {
  try {
    const { db } = await connectToDatabase()

    // Create collections if they don't exist
    const collections = await db.listCollections().toArray()
    const collectionNames = collections.map((c) => c.name)

    if (!collectionNames.includes("products")) {
      await db.createCollection("products")
      await db.collection("products").createIndex({ name: "text", description: "text" })
      await db.collection("products").createIndex({ category: 1 })
      await db.collection("products").createIndex({ featured: 1 })
    }

    if (!collectionNames.includes("users")) {
      await db.createCollection("users")
      await db.collection("users").createIndex({ email: 1 }, { unique: true })
    }

    if (!collectionNames.includes("orders")) {
      await db.createCollection("orders")
      await db.collection("orders").createIndex({ userId: 1 })
      await db.collection("orders").createIndex({ createdAt: -1 })
    }

    if (!collectionNames.includes("reviews")) {
      await db.createCollection("reviews")
      await db.collection("reviews").createIndex({ productId: 1 })
      await db.collection("reviews").createIndex({ userId: 1 })
    }

    if (!collectionNames.includes("admins")) {
      await db.createCollection("admins")
      await db.collection("admins").createIndex({ email: 1 }, { unique: true })
    }

    console.log("Database initialized successfully")
    return { success: true }
  } catch (error) {
    console.error("Database initialization failed:", error)
    return { success: false, error: error.message }
  }
}
