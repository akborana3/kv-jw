import { type NextRequest, NextResponse } from "next/server"
import { getDatabase } from "@/lib/mongodb"
import { verifyToken } from "@/lib/auth"
import { ObjectId } from "mongodb"

async function verifyAdmin(request: NextRequest) {
  const token = request.cookies.get("admin-token")?.value
  if (!token) {
    throw new Error("No admin token")
  }

  const decoded = verifyToken(token)
  if (!decoded || !decoded.isAdmin) {
    throw new Error("Invalid admin token")
  }

  return decoded
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await verifyAdmin(request)

    const db = await getDatabase()
    const order = await db.collection("orders").findOne({ _id: new ObjectId(params.id) })

    if (!order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 })
    }

    return NextResponse.json({ order })
  } catch (error) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
}
