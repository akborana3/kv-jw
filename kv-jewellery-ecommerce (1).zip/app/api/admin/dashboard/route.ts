import { type NextRequest, NextResponse } from "next/server"
import { getDatabase } from "@/lib/mongodb"
import { verifyToken } from "@/lib/auth"

async function verifyAdmin(request: NextRequest) {
  const token = request.cookies.get("admin-token")?.value
  if (!token) {
    throw new Error("No admin token")
  }

  const decoded = verifyToken(token)
  if (!decoded || !decoded.isAdmin) {
    throw new Error("Invalid admin token")
  }

  return decoded
}

export async function GET(request: NextRequest) {
  try {
    await verifyAdmin(request)

    const db = await getDatabase()

    // Get dashboard statistics
    const [totalProducts, totalOrders, totalUsers, pendingOrders, pendingReviews, recentOrders] = await Promise.all([
      db.collection("products").countDocuments(),
      db.collection("orders").countDocuments(),
      db.collection("users").countDocuments(),
      db.collection("orders").countDocuments({ status: "pending" }),
      db.collection("reviews").countDocuments({ approved: false }),
      db.collection("orders").find({}).sort({ createdAt: -1 }).limit(10).toArray(),
    ])

    // Calculate total revenue
    const orders = await db
      .collection("orders")
      .find({ status: { $ne: "cancelled" } })
      .toArray()
    const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0)

    return NextResponse.json({
      totalProducts,
      totalOrders,
      totalUsers,
      totalRevenue,
      pendingOrders,
      pendingReviews,
      recentOrders,
    })
  } catch (error) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
}
