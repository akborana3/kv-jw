import { type NextRequest, NextResponse } from "next/server"
import { getDatabase } from "@/lib/mongodb"
import { verifyToken, generateSlug } from "@/lib/auth"
import { ObjectId } from "mongodb"

async function verifyAdmin(request: NextRequest) {
  const token = request.cookies.get("admin-token")?.value
  if (!token) {
    throw new Error("No admin token")
  }

  const decoded = verifyToken(token)
  if (!decoded || !decoded.isAdmin) {
    throw new Error("Invalid admin token")
  }

  return decoded
}

export async function GET(request: NextRequest) {
  try {
    await verifyAdmin(request)

    const db = await getDatabase()
    const products = await db.collection("products").find({}).toArray()

    return NextResponse.json({ products })
  } catch (error) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
}

export async function POST(request: NextRequest) {
  try {
    await verifyAdmin(request)

    const productData = await request.json()
    const db = await getDatabase()

    const slug = generateSlug(productData.name)

    // Check if slug already exists
    const existingProduct = await db.collection("products").findOne({ slug })
    if (existingProduct) {
      return NextResponse.json({ error: "Product with this name already exists" }, { status: 400 })
    }

    const product = {
      ...productData,
      slug,
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    const result = await db.collection("products").insertOne(product)

    return NextResponse.json({
      success: true,
      productId: result.insertedId,
      slug,
    })
  } catch (error) {
    console.error("Create product error:", error)
    return NextResponse.json({ error: "Failed to create product" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    await verifyAdmin(request)

    const { _id, ...productData } = await request.json()
    const db = await getDatabase()

    const slug = generateSlug(productData.name)

    // Check if slug already exists for different product
    const existingProduct = await db.collection("products").findOne({
      slug,
      _id: { $ne: new ObjectId(_id) },
    })
    if (existingProduct) {
      return NextResponse.json({ error: "Product with this name already exists" }, { status: 400 })
    }

    const updatedProduct = {
      ...productData,
      slug,
      updatedAt: new Date(),
    }

    await db.collection("products").updateOne({ _id: new ObjectId(_id) }, { $set: updatedProduct })

    return NextResponse.json({ success: true, slug })
  } catch (error) {
    console.error("Update product error:", error)
    return NextResponse.json({ error: "Failed to update product" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    await verifyAdmin(request)

    const { searchParams } = new URL(request.url)
    const productId = searchParams.get("id")

    if (!productId) {
      return NextResponse.json({ error: "Product ID required" }, { status: 400 })
    }

    const db = await getDatabase()
    await db.collection("products").deleteOne({ _id: new ObjectId(productId) })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Delete product error:", error)
    return NextResponse.json({ error: "Failed to delete product" }, { status: 500 })
  }
}
