import { type NextRequest, NextResponse } from "next/server"
import { getDatabase } from "@/lib/mongodb"
import { verifyToken } from "@/lib/auth"
import { ObjectId } from "mongodb"

async function verifyAdmin(request: NextRequest) {
  const token = request.cookies.get("admin-token")?.value
  if (!token) {
    throw new Error("No admin token")
  }

  const decoded = verifyToken(token)
  if (!decoded || !decoded.isAdmin) {
    throw new Error("Invalid admin token")
  }

  return decoded
}

export async function GET(request: NextRequest) {
  try {
    await verifyAdmin(request)

    const db = await getDatabase()
    const reviews = await db.collection("reviews").find({}).sort({ createdAt: -1 }).toArray()

    return NextResponse.json({ reviews })
  } catch (error) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    await verifyAdmin(request)

    const { reviewId, approved } = await request.json()
    const db = await getDatabase()

    await db.collection("reviews").updateOne(
      { _id: new ObjectId(reviewId) },
      {
        $set: {
          approved,
          updatedAt: new Date(),
        },
      },
    )

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Update review error:", error)
    return NextResponse.json({ error: "Failed to update review" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    await verifyAdmin(request)

    const { searchParams } = new URL(request.url)
    const reviewId = searchParams.get("id")

    if (!reviewId) {
      return NextResponse.json({ error: "Review ID required" }, { status: 400 })
    }

    const db = await getDatabase()
    await db.collection("reviews").deleteOne({ _id: new ObjectId(reviewId) })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Delete review error:", error)
    return NextResponse.json({ error: "Failed to delete review" }, { status: 500 })
  }
}
