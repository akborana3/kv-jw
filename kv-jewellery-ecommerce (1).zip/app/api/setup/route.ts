import { type NextRequest, NextResponse } from "next/server"
import { getDatabase } from "@/lib/mongodb"
import { hashPassword } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    const db = await getDatabase()

    // Create indexes
    await db.collection("users").createIndex({ email: 1 }, { unique: true })
    await db.collection("products").createIndex({ slug: 1 }, { unique: true })
    await db.collection("products").createIndex({ category: 1 })
    await db.collection("orders").createIndex({ userId: 1 })
    await db.collection("reviews").createIndex({ productId: 1 })

    // Check if admin already exists
    const existingAdmin = await db.collection("admins").findOne({ email: "admin@kvjewellery.com" })

    if (!existingAdmin) {
      // Create admin user
      const hashedPassword = await hashPassword("admin123")
      await db.collection("admins").insertOne({
        email: "admin@kvjewellery.com",
        password: hashedPassword,
        name: "KV Admin",
        role: "admin",
        createdAt: new Date(),
      })
    }

    // Check if products exist
    const productCount = await db.collection("products").countDocuments()

    if (productCount === 0) {
      // Create sample products
      const sampleProducts = [
        {
          name: "Diamond Solitaire Ring",
          slug: "diamond-solitaire-ring",
          description: "Elegant diamond solitaire ring crafted in 18k white gold",
          price: 25000,
          originalPrice: 30000,
          category: "rings",
          images: ["https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=500"],
          inStock: true,
          featured: true,
          specifications: {
            metal: "18k White Gold",
            gemstone: "Diamond",
            weight: "2.5g",
          },
          createdAt: new Date(),
        },
        {
          name: "Gold Chain Necklace",
          slug: "gold-chain-necklace",
          description: "Beautiful 22k gold chain necklace for everyday wear",
          price: 15000,
          originalPrice: 18000,
          category: "necklaces",
          images: ["https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=500"],
          inStock: true,
          featured: true,
          specifications: {
            metal: "22k Gold",
            weight: "10g",
            length: "18 inches",
          },
          createdAt: new Date(),
        },
        {
          name: "Pearl Drop Earrings",
          slug: "pearl-drop-earrings",
          description: "Classic pearl drop earrings in sterling silver",
          price: 8000,
          originalPrice: 10000,
          category: "earrings",
          images: ["https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=500"],
          inStock: true,
          featured: false,
          specifications: {
            metal: "Sterling Silver",
            gemstone: "Pearl",
            weight: "3g",
          },
          createdAt: new Date(),
        },
        {
          name: "Tennis Bracelet",
          slug: "tennis-bracelet",
          description: "Sparkling diamond tennis bracelet in white gold",
          price: 35000,
          originalPrice: 40000,
          category: "bracelets",
          images: ["https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=500"],
          inStock: true,
          featured: true,
          specifications: {
            metal: "18k White Gold",
            gemstone: "Diamond",
            weight: "15g",
          },
          createdAt: new Date(),
        },
      ]

      await db.collection("products").insertMany(sampleProducts)
    }

    return NextResponse.json({
      success: true,
      message: "Database initialized successfully",
    })
  } catch (error) {
    console.error("Setup error:", error)
    return NextResponse.json({ error: "Setup failed" }, { status: 500 })
  }
}
