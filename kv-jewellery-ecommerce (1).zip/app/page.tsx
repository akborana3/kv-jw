import Navbar from "@/components/navbar"
import HeroSection from "@/components/hero-section"
import FeaturedProducts from "@/components/featured-products"
import WhyKVSection from "@/components/why-kv-section"
import BackToTop from "@/components/back-to-top"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <HeroSection />
      <FeaturedProducts />
      <WhyKVSection />
      <BackToTop />
    </main>
  )
}
