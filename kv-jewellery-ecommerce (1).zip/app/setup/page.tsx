"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, Loader2, Database } from "lucide-react"

export default function SetupPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [isComplete, setIsComplete] = useState(false)
  const [error, setError] = useState("")

  const initializeDatabase = async () => {
    setIsLoading(true)
    setError("")

    try {
      const response = await fetch("/api/setup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (response.ok) {
        setIsComplete(true)
      } else {
        const data = await response.json()
        setError(data.error || "Setup failed")
      }
    } catch (error) {
      setError("Network error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
            <Database className="w-6 h-6 text-primary" />
          </div>
          <CardTitle>KV Jewellery Setup</CardTitle>
          <CardDescription>Initialize your database with sample data and admin user</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!isComplete ? (
            <>
              <div className="space-y-2 text-sm text-muted-foreground">
                <p>This will create:</p>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Admin user (admin@kvjewellery.com)</li>
                  <li>Sample jewelry products</li>
                  <li>Database indexes</li>
                </ul>
              </div>

              {error && (
                <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-md">
                  <p className="text-sm text-destructive">{error}</p>
                </div>
              )}

              <Button onClick={initializeDatabase} disabled={isLoading} className="w-full">
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Initializing...
                  </>
                ) : (
                  "Initialize Database"
                )}
              </Button>
            </>
          ) : (
            <div className="text-center space-y-4">
              <CheckCircle className="mx-auto h-12 w-12 text-green-500" />
              <div>
                <h3 className="font-semibold text-green-700">Setup Complete!</h3>
                <p className="text-sm text-muted-foreground mt-2">Your database has been initialized successfully.</p>
              </div>

              <div className="space-y-2 text-sm">
                <div className="p-3 bg-muted rounded-md">
                  <p className="font-medium">Admin Credentials:</p>
                  <p>Email: admin@kvjewellery.com</p>
                  <p>Password: admin123</p>
                </div>
              </div>

              <div className="flex gap-2">
                <Button asChild className="flex-1">
                  <a href="/admin/login">Admin Panel</a>
                </Button>
                <Button variant="outline" asChild className="flex-1 bg-transparent">
                  <a href="/">Visit Store</a>
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
