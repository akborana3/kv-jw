"use client"

import { useState } from "react"
import Navbar from "@/components/navbar"
import ProductGrid from "@/components/product-grid"
import ProductFilters from "@/components/product-filters"
import BackToTop from "@/components/back-to-top"
import { Button } from "@/components/ui/button"
import { Filter, Grid, List } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export default function ShopPage() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [filters, setFilters] = useState({
    category: "",
    priceRange: [0, 10000],
    sortBy: "popularity",
  })

  return (
    <main className="min-h-screen pt-16">
      <Navbar />

      {/* Page Header */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-background to-yellow-400/5">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-playfair font-bold mb-4">
            Our{" "}
            <span className="bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
              Collection
            </span>
          </h1>
          <p className="text-lg text-muted-foreground">Discover our exquisite range of gold-plated silver jewellery</p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Desktop Filters */}
          <div className="hidden lg:block w-64 flex-shrink-0">
            <ProductFilters filters={filters} onFiltersChange={setFilters} />
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Mobile Filters & View Toggle */}
            <div className="flex items-center justify-between mb-6">
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" className="lg:hidden bg-transparent">
                    <Filter className="w-4 h-4 mr-2" />
                    Filters
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-80">
                  <ProductFilters filters={filters} onFiltersChange={setFilters} />
                </SheetContent>
              </Sheet>

              <div className="flex items-center gap-2">
                <Button
                  variant={viewMode === "grid" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setViewMode("grid")}
                >
                  <Grid className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setViewMode("list")}
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Products */}
            <ProductGrid viewMode={viewMode} filters={filters} />
          </div>
        </div>
      </div>

      <BackToTop />
    </main>
  )
}
