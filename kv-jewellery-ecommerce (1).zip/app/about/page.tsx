import Navbar from "@/components/navbar"
import BackToTop from "@/components/back-to-top"
import { Card, CardContent } from "@/components/ui/card"
import { Award, Users, Gem, Heart } from "lucide-react"

export default function AboutPage() {
  const values = [
    {
      icon: Gem,
      title: "Premium Quality",
      description: "Every piece is crafted with the finest materials and attention to detail",
    },
    {
      icon: Heart,
      title: "Customer First",
      description: "Your satisfaction is our priority, with dedicated support and service",
    },
    {
      icon: Award,
      title: "Excellence",
      description: "Committed to delivering exceptional jewelry that exceeds expectations",
    },
    {
      icon: Users,
      title: "Trust",
      description: "Building lasting relationships through transparency and reliability",
    },
  ]

  return (
    <main className="min-h-screen pt-16">
      <Navbar />

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-background to-yellow-400/5">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-playfair font-bold mb-6">
            About{" "}
            <span className="bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
              KV Jewellery
            </span>
          </h1>
          <p className="text-xl text-muted-foreground leading-relaxed">
            Crafting timeless elegance with premium gold-plated silver jewelry since our inception. We believe every
            piece should tell a story of luxury, quality, and sophistication.
          </p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-playfair font-bold mb-6">Our Story</h2>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  Founded with a passion for creating exceptional jewelry, KV Jewellery has been at the forefront of
                  luxury gold-plated silver jewelry design. Our journey began with a simple vision: to make premium
                  jewelry accessible to everyone without compromising on quality.
                </p>
                <p>
                  Each piece in our collection is meticulously crafted by skilled artisans who understand the art of
                  jewelry making. We combine traditional techniques with modern design sensibilities to create pieces
                  that are both timeless and contemporary.
                </p>
                <p>
                  Our commitment to excellence extends beyond our products to every aspect of your experience with us.
                  From the moment you browse our collection to the day your jewelry arrives at your doorstep, we ensure
                  every detail is perfect.
                </p>
              </div>
            </div>

            <div className="relative">
              <div className="aspect-square rounded-2xl overflow-hidden glass-effect">
                <div className="w-full h-full bg-gradient-to-br from-yellow-400/20 to-yellow-600/20 flex items-center justify-center">
                  <div className="text-center">
                    <Gem className="w-24 h-24 text-yellow-400 mx-auto mb-4" />
                    <p className="text-lg font-semibold">Crafted with Passion</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-background to-yellow-400/5">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-playfair font-bold mb-4">
              Our{" "}
              <span className="bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
                Values
              </span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              The principles that guide everything we do
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card
                key={value.title}
                className="glass-effect border-0 text-center hover:shadow-lg transition-all duration-300 hover:scale-105"
              >
                <CardContent className="p-8">
                  <div className="w-16 h-16 mx-auto mb-6 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center">
                    <value.icon className="w-8 h-8 text-black" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{value.title}</h3>
                  <p className="text-muted-foreground">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Quality Promise */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl sm:text-4xl font-playfair font-bold mb-8">
            Our Quality{" "}
            <span className="bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
              Promise
            </span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="space-y-4">
              <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center mx-auto">
                <span className="text-black font-bold text-xl">1</span>
              </div>
              <h3 className="text-xl font-semibold">Premium Materials</h3>
              <p className="text-muted-foreground">
                Only the finest silver base with premium gold plating for lasting beauty
              </p>
            </div>

            <div className="space-y-4">
              <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center mx-auto">
                <span className="text-black font-bold text-xl">2</span>
              </div>
              <h3 className="text-xl font-semibold">Expert Craftsmanship</h3>
              <p className="text-muted-foreground">Handcrafted by skilled artisans with years of experience</p>
            </div>

            <div className="space-y-4">
              <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center mx-auto">
                <span className="text-black font-bold text-xl">3</span>
              </div>
              <h3 className="text-xl font-semibold">Quality Assurance</h3>
              <p className="text-muted-foreground">Every piece undergoes rigorous quality checks before reaching you</p>
            </div>
          </div>

          <p className="text-lg text-muted-foreground">
            We stand behind every piece we create with our comprehensive warranty and satisfaction guarantee. Your trust
            in KV Jewellery is our most precious asset.
          </p>
        </div>
      </section>

      <BackToTop />
    </main>
  )
}
