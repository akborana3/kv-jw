"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import AdminLayout from "@/components/admin-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Package, ShoppingCart, Star, TrendingUp, DollarSign, Eye, AlertCircle } from "lucide-react"

interface DashboardStats {
  totalProducts: number
  totalOrders: number
  totalUsers: number
  totalRevenue: number
  pendingOrders: number
  pendingReviews: number
  recentOrders: any[]
  topProducts: any[]
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    fetchDashboardStats()
  }, [])

  const fetchDashboardStats = async () => {
    try {
      const response = await fetch("/api/admin/dashboard", {
        credentials: "include",
      })

      if (response.ok) {
        const data = await response.json()
        setStats(data)
      } else if (response.status === 401) {
        router.push("/admin/login")
      }
    } catch (error) {
      console.error("Failed to fetch dashboard stats:", error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-yellow-400"></div>
        </div>
      </AdminLayout>
    )
  }

  const statCards = [
    {
      title: "Total Products",
      value: stats?.totalProducts || 0,
      icon: Package,
      color: "text-blue-600",
      bgColor: "bg-blue-50 dark:bg-blue-900/20",
    },
    {
      title: "Total Orders",
      value: stats?.totalOrders || 0,
      icon: ShoppingCart,
      color: "text-green-600",
      bgColor: "bg-green-50 dark:bg-green-900/20",
    },
    {
      title: "Total Revenue",
      value: `₹${(stats?.totalRevenue || 0).toLocaleString()}`,
      icon: DollarSign,
      color: "text-yellow-600",
      bgColor: "bg-yellow-50 dark:bg-yellow-900/20",
    },
    {
      title: "Pending Orders",
      value: stats?.pendingOrders || 0,
      icon: AlertCircle,
      color: "text-red-600",
      bgColor: "bg-red-50 dark:bg-red-900/20",
    },
  ]

  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-playfair font-bold">
            Admin{" "}
            <span className="bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
              Dashboard
            </span>
          </h1>
          <p className="text-muted-foreground mt-2">Welcome back! Here's what's happening with your store.</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {statCards.map((stat, index) => (
            <Card key={index} className="glass-effect border-0">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                    <p className="text-2xl font-bold">{stat.value}</p>
                  </div>
                  <div className={`p-3 rounded-full ${stat.bgColor}`}>
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Recent Orders */}
          <Card className="glass-effect border-0">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-yellow-400" />
                Recent Orders
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {stats?.recentOrders?.slice(0, 5).map((order: any) => (
                  <div key={order._id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div>
                      <p className="font-medium">Order #{order._id.slice(-6)}</p>
                      <p className="text-sm text-muted-foreground">
                        {order.shippingInfo.firstName} {order.shippingInfo.lastName}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">₹{order.total.toLocaleString()}</p>
                      <Badge
                        variant={order.status === "delivered" ? "default" : "secondary"}
                        className={order.status === "delivered" ? "bg-green-500" : ""}
                      >
                        {order.status}
                      </Badge>
                    </div>
                  </div>
                )) || <p className="text-muted-foreground text-center py-4">No recent orders</p>}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="glass-effect border-0">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-yellow-400" />
                Quick Actions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <button
                  onClick={() => router.push("/admin/products/new")}
                  className="p-4 rounded-lg bg-yellow-400/10 hover:bg-yellow-400/20 transition-colors text-left"
                >
                  <Package className="w-8 h-8 text-yellow-400 mb-2" />
                  <p className="font-medium">Add Product</p>
                  <p className="text-sm text-muted-foreground">Create new product</p>
                </button>

                <button
                  onClick={() => router.push("/admin/orders")}
                  className="p-4 rounded-lg bg-blue-400/10 hover:bg-blue-400/20 transition-colors text-left"
                >
                  <ShoppingCart className="w-8 h-8 text-blue-400 mb-2" />
                  <p className="font-medium">View Orders</p>
                  <p className="text-sm text-muted-foreground">Manage orders</p>
                </button>

                <button
                  onClick={() => router.push("/admin/reviews")}
                  className="p-4 rounded-lg bg-green-400/10 hover:bg-green-400/20 transition-colors text-left"
                >
                  <Star className="w-8 h-8 text-green-400 mb-2" />
                  <p className="font-medium">Reviews</p>
                  <p className="text-sm text-muted-foreground">Moderate reviews</p>
                </button>

                <button
                  onClick={() => router.push("/")}
                  className="p-4 rounded-lg bg-purple-400/10 hover:bg-purple-400/20 transition-colors text-left"
                >
                  <Eye className="w-8 h-8 text-purple-400 mb-2" />
                  <p className="font-medium">View Store</p>
                  <p className="text-sm text-muted-foreground">Visit website</p>
                </button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  )
}
