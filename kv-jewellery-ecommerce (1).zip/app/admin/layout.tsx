"use client"

import type React from "react"

import { AdminAuthProvider } from "@/components/admin-auth-provider"

export default function AdminRootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <AdminAuthProvider>{children}</AdminAuthProvider>
}
