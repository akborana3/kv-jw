"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import AdminLayout from "@/components/admin-layout"
import ProductForm from "@/components/admin/product-form"
import { useToast } from "@/components/ui/use-toast"

export default function NewProductPage() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  const handleSubmit = async (productData: any) => {
    setIsSubmitting(true)

    try {
      const response = await fetch("/api/admin/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(productData),
        credentials: "include",
      })

      if (response.ok) {
        const data = await response.json()
        toast({
          title: "Product Created",
          description: `Product has been successfully created with slug: ${data.slug}`,
          className: "bg-gradient-to-r from-yellow-400 to-yellow-600 text-black",
        })
        router.push("/admin/products")
      } else {
        const error = await response.json()
        throw new Error(error.error || "Failed to create product")
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to create product. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-playfair font-bold">
            Add New{" "}
            <span className="bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
              Product
            </span>
          </h1>
          <p className="text-muted-foreground mt-2">Create a new product for your jewelry collection</p>
        </div>

        <ProductForm onSubmit={handleSubmit} isSubmitting={isSubmitting} />
      </div>
    </AdminLayout>
  )
}
