"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import AdminLayout from "@/components/admin-layout"
import ProductForm from "@/components/admin/product-form"
import { useToast } from "@/components/ui/use-toast"

export default function EditProductPage() {
  const [product, setProduct] = useState(null)
  const [loading, setLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const router = useRouter()
  const params = useParams()
  const { toast } = useToast()

  useEffect(() => {
    fetchProduct()
  }, [])

  const fetchProduct = async () => {
    try {
      const response = await fetch(`/api/admin/products/${params.id}`, {
        credentials: "include",
      })

      if (response.ok) {
        const data = await response.json()
        setProduct(data.product)
      } else if (response.status === 401) {
        router.push("/admin/login")
      } else {
        throw new Error("Product not found")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load product. Please try again.",
        variant: "destructive",
      })
      router.push("/admin/products")
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (productData: any) => {
    setIsSubmitting(true)

    try {
      const response = await fetch("/api/admin/products", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ _id: params.id, ...productData }),
        credentials: "include",
      })

      if (response.ok) {
        const data = await response.json()
        toast({
          title: "Product Updated",
          description: `Product has been successfully updated with slug: ${data.slug}`,
          className: "bg-gradient-to-r from-yellow-400 to-yellow-600 text-black",
        })
        router.push("/admin/products")
      } else {
        const error = await response.json()
        throw new Error(error.error || "Failed to update product")
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update product. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-yellow-400"></div>
        </div>
      </AdminLayout>
    )
  }

  if (!product) {
    return (
      <AdminLayout>
        <div className="text-center py-12">
          <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
          <p className="text-muted-foreground mb-8">The product you're trying to edit doesn't exist.</p>
          <button
            onClick={() => router.push("/admin/products")}
            className="bg-yellow-400 hover:bg-yellow-500 text-black px-6 py-2 rounded-lg"
          >
            Back to Products
          </button>
        </div>
      </AdminLayout>
    )
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-playfair font-bold">
            Edit{" "}
            <span className="bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
              Product
            </span>
          </h1>
          <p className="text-muted-foreground mt-2">Update product information</p>
        </div>

        <ProductForm initialData={product} onSubmit={handleSubmit} isSubmitting={isSubmitting} />
      </div>
    </AdminLayout>
  )
}
